# GameZone Community — Database Version

## Stack
- Frontend: HTML/CSS/JavaScript
- Database + authentication: Supabase
- Hosting: any static host

## Setup
1. Create a Supabase project.
2. Open SQL Editor and run `database.sql`.
3. Copy the project's URL and public anon key.
4. Put them in `config.js`.
5. Open/deploy `index.html`.

The browser must NEVER contain a Supabase `service_role` key. Only the public anon key belongs in `config.js`.

This version includes:
- email/password signup and login
- user profiles
- shared online posts
- game categories
- likes
- comments table and security policies (comment UI can be expanded next)
- row-level security
