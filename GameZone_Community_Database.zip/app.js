const configured=!SUPABASE_URL.startsWith("YOUR_")&&!SUPABASE_ANON_KEY.startsWith("YOUR_");
const sb=configured?supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY):null;
const $=id=>document.getElementById(id); let signup=false,current=null;

function openAuth(){ $("modal").classList.remove("hide");$("modalTitle").textContent=signup?"Create account":"Login";$("authForm").classList.remove("hide");$("postForm").classList.add("hide");}
function openPost(){if(!current){openAuth();return}$("modal").classList.remove("hide");$("modalTitle").textContent="New Post";$("authForm").classList.add("hide");$("postForm").classList.remove("hide")}
$("authBtn").onclick=openAuth;$("close").onclick=()=>$("modal").classList.add("hide");$("postBtn").onclick=openPost;
$("menu").onclick=()=>$("nav").classList.toggle("open");
$("switch").onclick=()=>{signup=!signup;$("modalTitle").textContent=signup?"Create account":"Login";$("username").classList.toggle("hide",!signup);$("authAction").textContent=signup?"Sign up":"Login";};
async function auth(){
 if(!configured)return alert("First add your Supabase URL and anon key in config.js.");
 const email=$("email").value.trim(),password=$("password").value,username=$("username").value.trim();
 if(signup){if(!username)return alert("Enter a username.");const {data,error}=await sb.auth.signUp({email,password});if(error)return alert(error.message);if(data.user){await sb.from("profiles").upsert({id:data.user.id,username});}}
 else {const {error}=await sb.auth.signInWithPassword({email,password});if(error)return alert(error.message)}
 $("modal").classList.add("hide");await loadUser();loadPosts();
}
$("authAction").onclick=auth;
async function loadUser(){if(!sb)return;const {data}=await sb.auth.getUser();current=data.user||null;$("authBtn").textContent=current?"Logout":"Login";if(current)$("authBtn").onclick=async()=>{await sb.auth.signOut();current=null;location.reload()}}
async function loadPosts(){
 if(!configured){$("status").textContent="Demo UI ready — connect Supabase to enable shared online posts.";return}
 const {data,error}=await sb.from("posts").select("id,title,body,game,created_at,likes,profiles(username)").order("created_at",{ascending:false}).limit(50);
 if(error){$("status").textContent=error.message;return}
 $("status").textContent=data.length+" discussion"+(data.length===1?"":"s")+" loaded";
 $("posts").innerHTML=data.map(p=>`<article class="post"><div class="meta">👤 ${esc(p.profiles?.username||"User")} • ${esc(p.game||"General")}</div><h3>${esc(p.title)}</h3><p>${esc(p.body)}</p><div class="actions"><button onclick="like('${p.id}',${p.likes||0})">❤️ ${p.likes||0}</button></div></article>`).join("");
}
async function like(id,count){const {error}=await sb.from("posts").update({likes:count+1}).eq("id",id);if(!error)loadPosts()}
$("publish").onclick=async()=>{if(!current)return openAuth();const title=$("postTitle").value.trim(),body=$("postBody").value.trim(),game=$("game").value;if(!title||!body)return alert("Fill title and discussion.");const {error}=await sb.from("posts").insert({title,body,game,user_id:current.id});if(error)return alert(error.message);$("modal").classList.add("hide");$("postTitle").value="";$("postBody").value="";loadPosts()};
function esc(x){return String(x??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
document.querySelectorAll(".games button").forEach(b=>b.onclick=()=>{$("game").value=b.dataset.game;openPost()});
if(configured){sb.auth.onAuthStateChange(()=>loadUser());loadUser()}loadPosts();
