// Paste your Supabase project values here.
// IMPORTANT: Use only the public anon key in this browser app.
// Never put a Supabase service_role key here.
const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
